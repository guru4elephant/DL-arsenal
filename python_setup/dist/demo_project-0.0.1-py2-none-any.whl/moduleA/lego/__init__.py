import sys
import os

print "import lego"
