import sys
import os

def xx(x = 1.0):
    print x + 1
