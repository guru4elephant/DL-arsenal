import sys
import os

print "hello wheel"
fin = open("data/datA.txt")
for line in fin:
    print line
